This is an android investment app, using Java and Android Studio that allows users to get real time stock data and stock news using New York Times and AlphaVantage APIs.

![screenOne](https://user-images.githubusercontent.com/118498961/229680727-0a2caf12-b6c5-4032-9356-8d3e052e6c89.PNG)
![screenTwo](https://user-images.githubusercontent.com/118498961/229680754-766f6f85-906a-4fab-9b0b-3106756e59d4.PNG)
